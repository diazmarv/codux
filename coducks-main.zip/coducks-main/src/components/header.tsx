export const Header = () => {
  return (
    <header className="">
      <h1 className="">coducks</h1>
    </header>
  );
};
